package com.hortonworks.simulator.impl.messages;

public class StartSimulation {

}
