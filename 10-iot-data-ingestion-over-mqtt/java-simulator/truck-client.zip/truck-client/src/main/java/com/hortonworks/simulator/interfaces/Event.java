package com.hortonworks.simulator.interfaces;

public interface Event {

}
