package com.hortonworks.simulator.interfaces;

public interface DomainObject {

}
